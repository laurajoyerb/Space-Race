#ifndef STATISTICS_H
#define STATISTICS_H

double getMedian(int * arr, int size);

int getLargest(int * arr, int size);

#endif
